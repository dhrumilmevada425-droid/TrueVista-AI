
const pages = document.querySelectorAll(".page");
const navButtons = document.querySelectorAll(".nav-btn");

function showPage(id) {
    pages.forEach(page => {
        page.classList.toggle("active", page.id === id);
    });

    navButtons.forEach(button => {
        button.classList.toggle("active", button.dataset.page === id);
    });

    window.scrollTo({ top: 0, behavior: "smooth" });
}

navButtons.forEach(button => {
    button.addEventListener("click", () => {
        showPage(button.dataset.page);
    });
});

document.querySelectorAll("[data-go]").forEach(button => {
    button.addEventListener("click", () => {
        showPage(button.dataset.go);
    });
});


// SCAM CHECK AND PROMPT SAFETY

async function scanText(text, type, resultElement) {
    resultElement.className = "result";
    resultElement.textContent = "Scanning...";

    if (!text.trim()) {
        resultElement.textContent = "Please enter some text.";
        return;
    }

    try {
        const response = await fetch("/scan", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({ text, type })
        });

        const data = await response.json();

        if (!response.ok) {
            throw new Error(data.error || "Scan failed.");
        }

        const heading = document.createElement("h3");
        heading.textContent = data.risk.toUpperCase() + " RISK";

        const score = document.createElement("p");
        score.textContent = `Risk score: ${data.score}/100`;

        const message = document.createElement("p");
        message.textContent = data.message;

        const reasonsTitle = document.createElement("strong");
        reasonsTitle.textContent = "Why flagged:";

        const reasons = document.createElement("ul");

        if (data.reasons.length) {
            data.reasons.forEach(reason => {
                const item = document.createElement("li");
                item.textContent = reason;
                reasons.appendChild(item);
            });
        } else {
            const item = document.createElement("li");
            item.textContent = "No configured warning signs matched.";
            reasons.appendChild(item);
        }

        resultElement.replaceChildren(
            heading,
            score,
            message,
            reasonsTitle,
            reasons
        );

        const riskClass = data.risk === "High"
            ? "risk-high"
            : data.risk === "Medium"
                ? "risk-medium"
                : "risk-low";

        resultElement.className = `result ${riskClass}`;

    } catch (error) {
        resultElement.className = "result risk-medium";
        resultElement.textContent = error.message;
    }
}

document.getElementById("checkScam").addEventListener("click", () => {
    scanText(
        document.getElementById("scamText").value,
        "scam",
        document.getElementById("scamResult")
    );
});

document.getElementById("checkPrompt").addEventListener("click", () => {
    scanText(
        document.getElementById("promptText").value,
        "prompt",
        document.getElementById("promptResult")
    );
});


// AUDIO AND VIDEO UPLOAD

const mediaInput = document.getElementById("mediaFile");
const mediaResult = document.getElementById("mediaResult");
const fileName = document.getElementById("fileName");
const mediaButton = document.getElementById("scanMedia");

mediaInput.addEventListener("change", () => {
    const file = mediaInput.files[0];

    fileName.textContent = file
        ? `${file.name} (${(file.size / 1024 / 1024).toFixed(2)} MB)`
        : "Choose an audio or video file.";
});

mediaButton.addEventListener("click", async () => {
    const file = mediaInput.files[0];

    mediaResult.className = "result";
    mediaResult.textContent = "";

    if (!file) {
        mediaResult.textContent = "Please select an audio or video file.";
        return;
    }

    if (file.size > 50 * 1024 * 1024) {
        mediaResult.className = "result risk-medium";
        mediaResult.textContent = "Maximum file size is 50 MB.";
        return;
    }

    mediaButton.disabled = true;
    mediaButton.textContent = "Analyzing...";

    try {
        const formData = new FormData();
        formData.append("file", file);

        const response = await fetch("/upload-media", {
            method: "POST",
            body: formData
        });

        const data = await response.json();

        if (!response.ok) {
            throw new Error(data.error || "Media analysis failed.");
        }

        const title = document.createElement("h3");
        title.textContent = "Recognized transcript";

        const transcript = document.createElement("p");
        transcript.textContent = data.transcript;

        const risk = document.createElement("h3");
        risk.textContent =
            `${data.analysis.risk.toUpperCase()} RISK — ` +
            `${data.analysis.score}/100`;

        const message = document.createElement("p");
        message.textContent = data.analysis.message;

        const reasons = document.createElement("p");
        reasons.textContent = data.analysis.reasons.length
            ? "Matched indicators: " +
              data.analysis.reasons.join(", ")
            : "No configured scam indicators matched.";

        const note = document.createElement("p");
        note.textContent = data.note;

        mediaResult.replaceChildren(
            title,
            transcript,
            risk,
            message,
            reasons,
            note
        );

        mediaResult.className = "result " +
            (data.analysis.risk === "High"
                ? "risk-high"
                : data.analysis.risk === "Medium"
                    ? "risk-medium"
                    : "risk-low");

    } catch (error) {
        mediaResult.className = "result risk-medium";
        mediaResult.textContent = error.message;
    } finally {
        mediaButton.disabled = false;
        mediaButton.textContent = "Analyze audio/video";
    }
});


// DEMO REPORTING

document.getElementById("sendReport").addEventListener("click", async () => {
    const message = document.getElementById("reportText").value.trim();
    const result = document.getElementById("reportResult");

    result.className = "result";

    if (!message) {
        result.textContent = "Please describe what happened.";
        return;
    }

    try {
        const response = await fetch("/report", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({ message })
        });

        const data = await response.json();

        if (!response.ok) {
            throw new Error(data.error || "Report failed.");
        }

        result.textContent = data.message;
        result.className = "result risk-low";

    } catch (error) {
        result.textContent = error.message;
        result.className = "result risk-medium";
    }
});


// AWARENESS QUIZ

const questions = [
    {
        question: "A caller imitates your son's voice and asks for money. What do you do?",
        answers: [
            "Send it fast",
            "Call your son on a saved number",
            "Ask for his UPI PIN"
        ],
        correct: 1,
        explanation: "Verify using a trusted, saved contact number."
    },
    {
        question: "Someone asks you to share an OTP. What should you do?",
        answers: [
            "Share it immediately",
            "Post it online",
            "Never share it"
        ],
        correct: 2,
        explanation: "Never share your OTP, password or PIN."
    },
    {
        question: "A message says your bank account will be blocked urgently. What is best?",
        answers: [
            "Click the link",
            "Verify using the official bank app or number",
            "Reply with your password"
        ],
        correct: 1,
        explanation: "Verify account warnings through official channels."
    },
    {
        question: "How should you handle a suspicious link?",
        answers: [
            "Open it immediately",
            "Forward it to everyone",
            "Avoid clicking and verify the sender"
        ],
        correct: 2,
        explanation: "Suspicious links may lead to phishing websites."
    },
    {
        question: "An AI-generated video shows someone saying something surprising. What should you do?",
        answers: [
            "Believe it immediately",
            "Check reliable sources before sharing",
            "Assume every video is real"
        ],
        correct: 1,
        explanation: "Verify unexpected claims before trusting or sharing them."
    }
];

let questionIndex = 0;
let quizScore = 0;
let answered = false;

const questionElement = document.getElementById("question");
const answersElement = document.getElementById("answers");
const feedbackElement = document.getElementById("quizFeedback");
const nextButton = document.getElementById("nextQuestion");
const restartButton = document.getElementById("restartQuiz");

function renderQuestion() {
    answered = false;

    const item = questions[questionIndex];

    document.getElementById("quizProgress").textContent =
        `Question ${questionIndex + 1} of ${questions.length}`;

    questionElement.textContent = item.question;
    answersElement.replaceChildren();
    feedbackElement.textContent = "";

    nextButton.disabled = true;
    nextButton.classList.remove("hidden");
    nextButton.textContent =
        questionIndex === questions.length - 1
            ? "Finish quiz"
            : "Next";

    restartButton.classList.add("hidden");

    item.answers.forEach((answer, index) => {
        const button = document.createElement("button");

        button.className = "answer";
        button.textContent = answer;

        button.addEventListener("click", () => {
            if (answered) return;

            answered = true;

            const correct = index === item.correct;

            if (correct) {
                quizScore++;
            }

            [...answersElement.children].forEach((choice, i) => {
                choice.disabled = true;

                if (i === item.correct) {
                    choice.classList.add("correct");
                } else if (i === index) {
                    choice.classList.add("wrong");
                }
            });

            feedbackElement.textContent =
                (correct ? "Correct! " : "Not quite. ") +
                item.explanation;

            nextButton.disabled = false;
        });

        answersElement.appendChild(button);
    });
}

nextButton.addEventListener("click", () => {
    if (!answered) return;

    if (questionIndex < questions.length - 1) {
        questionIndex++;
        renderQuestion();
    } else {
        questionElement.textContent =
            `Quiz complete! Your score: ${quizScore}/${questions.length}`;

        answersElement.replaceChildren();

        document.getElementById("quizProgress").textContent = "Completed";
        feedbackElement.textContent =
            "Keep practising safe online habits.";

        nextButton.classList.add("hidden");
        restartButton.classList.remove("hidden");
    }
});

restartButton.addEventListener("click", () => {
    questionIndex = 0;
    quizScore = 0;
    renderQuestion();
});

renderQuestion();
