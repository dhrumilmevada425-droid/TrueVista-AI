
import os
import subprocess
import tempfile

import speech_recognition as sr
from flask import Flask, jsonify, render_template, request
from werkzeug.utils import secure_filename

app = Flask(
    __name__,
    static_folder="assets",
    static_url_path="/assets"
)

app.config["MAX_CONTENT_LENGTH"] = 50 * 1024 * 1024

ALLOWED_MEDIA = {
    ".wav", ".mp3", ".m4a", ".ogg", ".flac",
    ".mp4", ".mov", ".avi", ".mkv", ".webm"
}

SCAM_RULES = {
    "share your otp": 40,
    "otp": 30,
    "urgently": 20,
    "urgent": 20,
    "blocked": 20,
    "account suspended": 30,
    "bit.ly": 30,
    "password": 30,
    "send money": 30,
    "click here": 20,
    "verify your account": 25,
    "claim your prize": 30,
    "upi pin": 30,
    "gift card": 25,
    "account will be blocked": 30,
    "send the code": 30,
    "click the link": 20,
    "you have won": 25
}

PROMPT_RULES = {
    "ignore all previous instructions": 40,
    "ignore previous instructions": 40,
    "reveal your system prompt": 40,
    "reveal system prompt": 40,
    "jailbreak": 30,
    "bypass safety": 30,
    "disregard your instructions": 40,
    "reveal hidden instructions": 40,
    "ignore all rules": 30
}


def analyze_text(text, scan_type="scam"):
    text = str(text).strip().lower()

    rules = PROMPT_RULES if scan_type == "prompt" else SCAM_RULES
    matched = [phrase for phrase in rules if phrase in text]
    score = min(100, sum(rules[phrase] for phrase in matched))

    if score >= 60:
        risk = "High"
        message = (
            "High risk: Do not click links or share sensitive "
            "information. Verify through official channels."
        )
    elif score >= 25:
        risk = "Medium"
        message = (
            "Medium risk: Verify the sender before taking action."
        )
    else:
        risk = "Low"
        message = (
            "Low detected risk. This does not guarantee the "
            "content is safe."
        )

    return {
        "risk": risk,
        "score": score,
        "reasons": matched,
        "message": message
    }


@app.route("/")
def home():
    return render_template("index.html")


@app.route("/scan", methods=["POST"])
def scan():
    data = request.get_json(silent=True) or {}

    text = str(data.get("text", "")).strip()
    scan_type = data.get("type", "scam")

    if not text:
        return jsonify({"error": "Please enter some text."}), 400

    if scan_type not in ("scam", "prompt"):
        return jsonify({"error": "Invalid scan type."}), 400

    return jsonify(analyze_text(text, scan_type))


@app.route("/report", methods=["POST"])
def report():
    data = request.get_json(silent=True) or {}
    message = str(data.get("message", "")).strip()

    if not message:
        return jsonify({
            "error": "Enter a message to report."
        }), 400

    return jsonify({
        "success": True,
        "message": (
            "Demo report received. It was not stored or sent."
        )
    })


def transcribe_audio(audio_path):
    recognizer = sr.Recognizer()

    with sr.AudioFile(audio_path) as source:
        audio = recognizer.record(source)

    return recognizer.recognize_google(audio)


@app.route("/upload-media", methods=["POST"])
def upload_media():
    uploaded = request.files.get("file")

    if not uploaded or not uploaded.filename:
        return jsonify({
            "error": "Please select an audio or video file."
        }), 400

    filename = secure_filename(uploaded.filename)
    extension = os.path.splitext(filename)[1].lower()

    if extension not in ALLOWED_MEDIA:
        return jsonify({
            "error": "Unsupported audio/video format."
        }), 400

    try:
        with tempfile.TemporaryDirectory() as folder:
            original_path = os.path.join(folder, filename)
            audio_path = os.path.join(folder, "converted.wav")

            uploaded.save(original_path)

            command = [
                "ffmpeg", "-nostdin", "-y",
                "-i", original_path,
                "-vn",
                "-ac", "1",
                "-ar", "16000",
                "-t", "120",
                audio_path
            ]

            subprocess.run(
                command,
                capture_output=True,
                text=True,
                timeout=90,
                check=True
            )

            transcript = transcribe_audio(audio_path)
            analysis = analyze_text(transcript, "scam")

            return jsonify({
                "filename": filename,
                "transcript": transcript,
                "analysis": analysis,
                "note": (
                    "Keyword analysis only. AI voice and visual "
                    "deepfake detection are not implemented."
                )
            })

    except sr.UnknownValueError:
        return jsonify({
            "error": "Speech was unclear. Try a clearer recording."
        }), 422

    except sr.RequestError:
        return jsonify({
            "error": (
                "Speech recognition failed. Check your internet "
                "connection and try again."
            )
        }), 502

    except subprocess.TimeoutExpired:
        return jsonify({
            "error": "Processing took too long. Try a shorter file."
        }), 422

    except subprocess.CalledProcessError:
        return jsonify({
            "error": (
                "Could not extract audio. Check that the file "
                "contains a valid audio track."
            )
        }), 422

    except FileNotFoundError:
        return jsonify({
            "error": (
                "FFmpeg was not found. Install FFmpeg and add "
                "it to your Windows PATH."
            )
        }), 500

    except Exception:
        app.logger.exception("Media processing failed")
        return jsonify({
            "error": "Media processing failed. Check the terminal."
        }), 500


@app.errorhandler(413)
def file_too_large(error):
    return jsonify({
        "error": "File is too large. Maximum size is 50 MB."
    }), 413


if __name__ == "__main__":
    app.run(debug=True)
